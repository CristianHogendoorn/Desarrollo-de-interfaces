﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tres_en_raya
{
    public partial class Form1 : Form
    {

        String jugador1 = "X";
        String jugador2 = "O";
        int turno = 1;
        int time;

        public Form1()
        {
            InitializeComponent();

            time = 0;
            TimeLabel.Text = "0 s";
            timer1.Start();
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Label clickedLabel = sender as Label;




        if (clickedLabel.Text == "")
        {
            if (turno % 2 != 0)
            {
                clickedLabel.Text = jugador1;
                   label11.Text = jugador2;
            } 
            else
            {
                clickedLabel.Text = jugador2;
                   label11.Text = jugador1;
            }
            turno++;
        } else {
            clickedLabel.Text = "";
        }


        comprobarSiGana();
            

            

            

        }
        public void comprobarSiGana()
        {
            if (label1.Text == label2.Text && label1.Text == label3.Text && label1.Text != "")
            {
                MessageBox.Show("El ganador es el jugador "+label1.Text);
                Close();
            }
            if (label4.Text == label5.Text && label4.Text == label6.Text && label4.Text != "")
            {
                MessageBox.Show("El ganador es el jugador " + label4.Text);
                Close();
            }
            if (label7.Text == label8.Text && label7.Text == label9.Text && label7.Text != "")
            {
                MessageBox.Show("El ganador es el jugador " + label7.Text);
                Close();
            }

            if (label1.Text == label4.Text && label1.Text == label7.Text && label1.Text != "")
            {
                MessageBox.Show("El ganador es el jugador " + label1.Text);
                Close();
            }
            if (label2.Text == label5.Text && label2.Text == label8.Text && label2.Text != "")
            {
                MessageBox.Show("El ganador es el jugador " + label2.Text);
                Close();
            }
            if (label3.Text == label6.Text && label3.Text == label9.Text && label3.Text != "")
            {
                MessageBox.Show("El ganador es el jugador " + label3.Text);
                Close();
            }

            if (label1.Text == label5.Text && label1.Text == label9.Text && label1.Text != "")
            {
                MessageBox.Show("El ganador es el jugador " + label1.Text);
                Close();
            }
            if (label3.Text == label5.Text && label3.Text == label7.Text && label3.Text != "")
            {
                MessageBox.Show("El ganador es el jugador " + label3.Text);
                Close();
            }
        }

        private void timer1_tick(object sender, EventArgs e)
        {
            time++;
            TimeLabel.Text = time+" s";
        }
    }
}
